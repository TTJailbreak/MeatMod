package com.planetbravo.mainmod;

import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.effect.EntityLightningBolt;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item.ToolMaterial;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemSword;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.ResourceLocation;
import net.minecraft.world.World;
import net.minecraftforge.fml.common.registry.GameRegistry;

public class ItemSix extends ItemSword {
	private ResourceLocation location;
	public ItemSix ( String unlocalizedName , ToolMaterial material ) {
		super ( material );
		setUnlocalizedName ( unlocalizedName );
		this . setCreativeTab (Register.mainTab);
		this . location = new ResourceLocation ( Main . MODID , unlocalizedName );
		this . setRegistryName ( location );
		GameRegistry . register ( this );
	}

	@Override
	public void onUpdate(ItemStack stack, World worldIn, Entity entityIn, int itemSlot, boolean isSelected) {
		super.onUpdate(stack, worldIn, entityIn, itemSlot, isSelected);
		
		effectPlayer((EntityLivingBase) entityIn, Potion.getPotionById(1), 2);
		
	}

	private void effectPlayer ( EntityLivingBase player , Potion potion , int amplifier ) {
		if ( player . getActivePotionEffect ( potion ) == null ||
		player . getActivePotionEffect ( potion ). getDuration () <= 1)
		player . addPotionEffect ( new PotionEffect ( potion , 159 , amplifier , true , true ));
	}
	
	@Override
	public boolean hitEntity(ItemStack stack, net.minecraft.entity.EntityLivingBase target,
			net.minecraft.entity.EntityLivingBase attacker) {

		EntityPlayer entityplayer = (EntityPlayer) attacker;
		World world = attacker.getEntityWorld();

		int x = target.getPosition().getX();
		int y = target.getPosition().getY();
		int z = target.getPosition().getZ();
		
		effectPlayer(target, Potion.getPotionById(2), 2);
		effectPlayer(target, Potion.getPotionById(6), 1);

		world.addWeatherEffect(new EntityLightningBolt(world, x, y, z, true));
		
		return super.hitEntity(stack, target, attacker);
		
		


}


}