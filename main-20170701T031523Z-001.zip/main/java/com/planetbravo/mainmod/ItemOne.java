package com.planetbravo.mainmod;

import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.item.Item;
import net.minecraft.item.ItemBlock;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.fml.common.registry.GameRegistry;

public class ItemOne extends Item {
	
	private ResourceLocation location;
	
	public ItemOne(String unlocalizedName){
		super();
		this.setUnlocalizedName(unlocalizedName);
		this.setCreativeTab(Register.mainTab);
		this.location = new ResourceLocation(Main.MODID, unlocalizedName);
		this.setRegistryName(location);
		GameRegistry.register(this);
	}
}