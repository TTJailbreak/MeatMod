package com.planetbravo.mainmod;

import java.util.Random;

import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.item.Item;
import net.minecraft.item.ItemBlock;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.fml.common.registry.GameRegistry;

public class BlockTen extends Block {

	private ResourceLocation location;

	public BlockTen(String unlocalizedName) {
		super(Material.CLOTH);
		this.setUnlocalizedName(unlocalizedName);
		this.setCreativeTab(Register.mainTab);
		this.setHardness(2.0F);
		this.setResistance(10.0F);
		location = new ResourceLocation(Main.MODID, unlocalizedName);
		this.setRegistryName(location);
		GameRegistry.register(this);
		GameRegistry.register(new ItemBlock(this), location);
	}
}