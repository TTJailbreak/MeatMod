package com.planetbravo.mainmod;

import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.item.Item;
import net.minecraft.item.ItemFood;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.fml.common.registry.GameRegistry;

public class ItemTen extends ItemFood {
	
	private ResourceLocation location;
	
	public ItemTen(String unlocalizedName){
		this(unlocalizedName, 5, true);
	}
	
	public ItemTen(String unlocalizedName, int i, boolean b){
		super(i, 0.2f, b);
		this.setUnlocalizedName(unlocalizedName);
		this.setCreativeTab(Register.mainTab);
		this.setAlwaysEdible();
		this.location = new ResourceLocation(Main.MODID, unlocalizedName);
		this.setRegistryName(location);
		GameRegistry.register(this);
	}
}