//Copy this code in a class called RenderDogOne
package com.planetbravo.mainmod;

import org.lwjgl.opengl.GL11;

import net.minecraft.client.Minecraft;
import net.minecraft.client.model.ModelWolf;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.client.renderer.entity.RenderWolf;
import net.minecraft.entity.passive.EntityWolf;
import net.minecraft.util.ResourceLocation;

public class RenderDogOne extends RenderWolf {

	private static final ResourceLocation textureLocation = new ResourceLocation(
			Main.MODID + ":" + "textures/entities/entitydogone.png");
	
	public RenderDogOne(RenderManager manager) {
		super(manager);
	}

	@Override
	protected void preRenderCallback(EntityWolf entitylivingbaseIn, float partialTickTime) {
		super.preRenderCallback(entitylivingbaseIn, partialTickTime);
		float scale = 1.0F;
		GL11.glScalef(scale, scale, scale);
	}



	@Override
	protected ResourceLocation getEntityTexture(EntityWolf par1Entity) {
		return textureLocation;
	}
}