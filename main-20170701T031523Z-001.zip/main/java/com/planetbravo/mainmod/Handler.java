
package com.planetbravo.mainmod;

import net.minecraftforge.event.entity.player.PlayerInteractEvent.EntityInteract;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class Handler {
	
	@SubscribeEvent
	public void rightClickerOfTheClicks(EntityInteract event){
		
	}
	
}
