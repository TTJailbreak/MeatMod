//Copy this code in a new class called EntityDogOne
package com.planetbravo.mainmod;

import java.util.UUID;

import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityAgeable;
import net.minecraft.entity.passive.EntityWolf;
import net.minecraft.util.ResourceLocation;
import net.minecraft.world.World;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.registry.GameRegistry;

public class EntityDogOne extends EntityWolf {

	private ResourceLocation location;
	
	public EntityDogOne(World par1World) {
		super(par1World);
		location = new ResourceLocation(Main.MODID, "entitydogone");
	}
	
	@Override
	public EntityDogOne createChild(EntityAgeable ageable) {
		EntityDogOne entityDog = new EntityDogOne(this.world);
        UUID s = this.getOwnerId();

        if (s != null)
        {
            entityDog.setOwnerId(s);
            entityDog.setTamed(true);
        }
        return entityDog;
	}
	
	@Override
	public boolean hitByEntity(Entity entityIn) {
		this.getOwner().startRiding(this);
		return super.hitByEntity(entityIn);
		
	}
		
}