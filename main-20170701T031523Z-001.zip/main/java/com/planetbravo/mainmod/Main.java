package com.planetbravo.mainmod;

import java.awt.Color;

import net.minecraft.client.Minecraft;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.fml.client.registry.RenderingRegistry;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.Mod.EventHandler;
import net.minecraftforge.fml.common.Mod.Instance;
import net.minecraftforge.fml.common.SidedProxy;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPostInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import net.minecraftforge.fml.common.registry.EntityRegistry;

@Mod(modid = Main.MODID, name = Main.MODNAME, version = Main.VERSION)
public class Main {
	
	public static final String MODID = "mainmod";
    public static final String MODNAME = "The Meat Mod";
    public static final String VERSION = "3.1.4";
    
    private static int modEntities = 0;
    
    @Instance
    public static Main instance = new Main();
        
    @SidedProxy(clientSide="com.planetbravo.mainmod.ClientProxy")
    public static CommonProxy proxy;

    @EventHandler
    public void preInit(FMLPreInitializationEvent e) {
    	this.proxy.preInit(e);
    	Register.addRecipes();
    	register(EntityDogOne.class, "entitydogone", 0xFFA800, 0xFF8400);
    	RenderingRegistry.registerEntityRenderingHandler(EntityDogOne.class, RenderDogOne::new);    	
    	register(EntityDogTwo.class, "entitydogtwo", 0xFF0000, 0xFF8400);
    	RenderingRegistry.registerEntityRenderingHandler(EntityDogTwo.class, RenderDogTwo::new);
    	register(EntityOne.class, "entityone", 0xC87500, 0xFF8400);
    	RenderingRegistry.registerEntityRenderingHandler(EntityOne.class, RenderEntityOne::new);
    	register(EntityTwo.class, "entitytwo", 0xFF5500, 0xFF8400);
    	RenderingRegistry.registerEntityRenderingHandler(EntityTwo.class, RenderEntityTwo::new);
    	register(DragonOne.class, "dragonone", 0xFF5500, 0xFF8400);
    	RenderingRegistry.registerEntityRenderingHandler(DragonOne.class, RenderDragonOne::new);
    	
    }
    
	@EventHandler
    public void init(FMLInitializationEvent e) {
    	this.proxy.init(e);
    }

    @EventHandler
    public void postInit(FMLPostInitializationEvent e) {
    	this.proxy.postInit(e);
    }
    
    public static void register(Class EntityClass, String entityNameIn, int in, int out){
		EntityRegistry.registerModEntity(new ResourceLocation(Main.MODID + ":" + entityNameIn), EntityClass, entityNameIn, ++modEntities, instance, 64, 1, true, in, out);
	}

    
}