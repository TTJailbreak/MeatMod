package com.planetbravo.mainmod;

import net.minecraft.block.Block;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.block.model.ModelResourceLocation;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.init.Items;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.item.Item;
import net.minecraft.item.Item.ToolMaterial;
import net.minecraft.item.ItemArmor.ArmorMaterial;
import net.minecraft.item.ItemStack;
import net.minecraftforge.client.model.ModelLoader;
import net.minecraftforge.common.util.EnumHelper;
import net.minecraftforge.fml.common.registry.GameRegistry;

public final class Register {

	public static String modid = Main.MODID;

	public static Block blockone;
	public static Block blocktwo;
	public static Block blockthree;
	public static Block blockfour;
	public static Block blockfive;
	public static Block blocksix;
	public static Block blockseven;
	public static Block blockeight;
	public static Block blocknine;
	public static Block blockten;
	public static Block blockeleven;
	public static Block blocktwelve;
	public static Block blockthirteen;
	public static Block blockfourteen;
	public static Block blockfifteen;
	public static Block blockpilot;
	public static WorldGen genone;
	public static Item itemone;
	public static Item itemtwo;
	public static Item itemthree;
	public static Item itemfour;
	public static Item itemfive;
	public static Item itemsix;
	public static Item itemseven;
	public static Item itemeight;
	public static Item itemnine;
	public static Item itemten;
	public static Item itemeleven;
	public static Item itemtwelve;
	public static Item itemthirteen;
	public static Item itemfourteen;
	public static Item itemfifteen;
	public static Item itemsixteen;
	public static ArmorMaterial ARMORONE = EnumHelper.addArmorMaterial("armorone", "mainmod:armorone", 16, new int[] {3, 5, 4, 3}, 30, null, 0);
    public static Item armorhelmetone;
    public static Item armorchestplateone;
    public static Item armorleggingsone;
    public static Item armorbootsone;
    public static ArmorMaterial ARMORTWO = EnumHelper.addArmorMaterial("armortwo", "mainmod:armortwo", 16, new int[] {2, 4, 3, 2}, 30, null, 0);
    public static Item armorhelmettwo;
    public static Item armorchestplatetwo;
    public static Item armorleggingstwo;
    public static Item armorbootstwo;
    public static CreativeTabs mainTab = new MainTab("meatModMenu");



	public static void addRecipes() {
		GameRegistry.addRecipe(new ItemStack(blocktwo, 1), new Object[] {
    			"DDD",
    			"DDD",
    			"DDD",
    			'D', itemone
    		});
		
		GameRegistry.addRecipe(new ItemStack(blockthree, 1), new Object[] {
    			"DDD",
    			"DDD",
    			"DDD",
    			'D', Items.CHICKEN
    		});
		
		GameRegistry.addRecipe(new ItemStack(blockfour, 1), new Object[] {
    			"DDD",
    			"DDD",
    			"DDD",
    			'D', blockthree
    		});
		
		GameRegistry.addRecipe(new ItemStack(blockfive, 1), new Object[] {
    			"DDD",
    			"DDD",
    			"DDD",
    			'D', Items.COOKED_CHICKEN
    		});
		
		GameRegistry.addRecipe(new ItemStack(blocksix, 1), new Object[] {
    			"DDD",
    			"DDD",
    			"DDD",
    			'D', blockfive
    		});
		
		GameRegistry.addRecipe(new ItemStack(blockseven, 1), new Object[] {
    			"EDE",
    			"DED",
    			"EDE",
    			'D', Items.PORKCHOP, 'E', Items.BEEF
    		});
		
		GameRegistry.addRecipe(new ItemStack(blockeight, 1), new Object[] {
    			"DDD",
    			"DDD",
    			"DDD",
    			'D', blockseven
    		});
		
		
		GameRegistry.addRecipe(new ItemStack(Items.CHICKEN, 9), new Object[] {
    			"   ",
    			" D ",
    			"   ",
    			'D', blockthree
    		});

		GameRegistry.addRecipe(new ItemStack(blockthree, 9), new Object[] {
    			"   ",
    			" D ",
    			"   ",
    			'D', blockfour
    		});
		
		GameRegistry.addRecipe(new ItemStack(Items.COOKED_CHICKEN, 9), new Object[] {
    			"   ",
    			" D ",
    			"   ",
    			'D', blockfive
    		});
		
		GameRegistry.addRecipe(new ItemStack(blockfive, 9), new Object[] {
    			"   ",
    			" D ",
    			"   ",
    			'D', blocksix
    		});
		
		GameRegistry.addRecipe(new ItemStack(Items.BEEF, 5), new Object[] {
    			"   ",
    			" DE",
    			"   ",
    			'D', blockseven, 'E',Items.BEEF
    		});
		
		GameRegistry.addRecipe(new ItemStack(Items.PORKCHOP, 4), new Object[] {
    			"   ",
    			" DE",
    			"   ",
    			'D', blockseven, 'E',Items.PORKCHOP
    		});
		
		GameRegistry.addRecipe(new ItemStack(blockseven, 9), new Object[] {
    			"   ",
    			" D ",
    			"   ",
    			'D', blockeight
    		});
		
		GameRegistry.addRecipe(new ItemStack(blockseven, 9), new Object[] {
    			"   ",
    			" D ",
    			"   ",
    			'D', blockeight
    		});
		
		GameRegistry.addRecipe(new ItemStack(Items.COOKED_BEEF, 5), new Object[] {
    			"   ",
    			" DE",
    			"   ",
    			'D', blockseven, 'E',Items.COOKED_BEEF
    		});
		
		GameRegistry.addRecipe(new ItemStack(Items.COOKED_PORKCHOP, 4), new Object[] {
    			"   ",
    			" DE",
    			"   ",
    			'D', blockseven, 'E',Items.COOKED_PORKCHOP
    		});
		
		GameRegistry.addRecipe(new ItemStack(armorhelmettwo, 1), new Object[] {
    			"DDD",
    			"D D",
    			"   ",
    			'D', itemfour
    		});
		
		GameRegistry.addRecipe(new ItemStack(armorchestplatetwo, 1), new Object[] {
    			"D D",
    			"DDD",
    			"DDD",
    			'D', itemfour
    		});
		
		GameRegistry.addRecipe(new ItemStack(armorleggingstwo, 1), new Object[] {
    			"DDD",
    			"D D",
    			"D D",
    			'D', itemfour
    		});
		
		GameRegistry.addRecipe(new ItemStack(armorbootstwo, 1), new Object[] {
    			"   ",
    			"D D",
    			"D D",
    			'D', itemfour
    		});
		
		GameRegistry.addRecipe(new ItemStack(itemfour, 1), new Object[] {
    			" D ",
    			"EHF",
    			" G ",
    			'D', Items.COOKED_BEEF, 'E', Items.COOKED_CHICKEN, 'F', Items.COOKED_PORKCHOP, 'G', Items.COOKED_FISH, 'H', Items.STICK
    		});
		
		GameRegistry.addRecipe(new ItemStack(itemtwo, 1), new Object[] {
    			" E ",
    			" E ",
    			" D ",
    			'D', Items.STICK, 'E', itemone
    		});
		
		GameRegistry.addRecipe(new ItemStack(itemthree, 1), new Object[] {
    			" EE",
    			" DE",
    			" D ",
    			'D', Items.STICK, 'E', itemone
    		});
		
		GameRegistry.addRecipe(new ItemStack(itemfive, 1), new Object[] {
    			" E ",
    			" D ",
    			" D ",
    			'D', Items.STICK, 'E', itemone
    		});
		
		GameRegistry.addRecipe(new ItemStack(itemsix, 1), new Object[] {
    			" E ",
    			"FDF",
    			" E ",
    			'D', Items.IRON_INGOT, 'E', Items.STICK, 'F', itemone
    		});
		
		GameRegistry.addRecipe(new ItemStack(itemseven, 1), new Object[] {
    			" E ",
    			"DED",
    			" D ",
    			'D', Items.STICK, 'E', itemone
    		});
		
		GameRegistry.addRecipe(new ItemStack(itemeight, 1), new Object[] {
    			" EE",
    			" D ",
    			" D ",
    			'D', Items.STICK, 'E', itemone
    		});
		
		GameRegistry.addRecipe(new ItemStack(itemnine, 1), new Object[] {
    			"EEE",
    			" D ",
    			" D ",
    			'D', Items.STICK, 'E', itemone
    		});
		
		GameRegistry.addRecipe(new ItemStack(itemnine, 1), new Object[] {
    			"EEE",
    			" D ",
    			" D ",
    			'D', Items.STICK, 'E', itemone
    		});
		
		GameRegistry.addRecipe(new ItemStack(itemten, 1), new Object[] {
    			"EEE",
    			"EEE",
    			"EEE",
    			'E', Items.BEEF
    		});
		
		GameRegistry.addRecipe(new ItemStack(Items.BEEF, 9), new Object[] {
    			"   ",
    			" D ",
    			"   ",
    			'D', itemten
    		});
		
		GameRegistry.addRecipe(new ItemStack(itemeleven, 1), new Object[] {
    			"EEE",
    			"EEE",
    			"EEE",
    			'E', Items.COOKED_BEEF
    		});
		
		GameRegistry.addRecipe(new ItemStack(Items.COOKED_BEEF, 9), new Object[] {
    			"   ",
    			" D ",
    			"   ",
    			'D', itemeleven
    		});
		
		GameRegistry.addRecipe(new ItemStack(itemtwelve, 1), new Object[] {
    			"EEE",
    			"EEE",
    			"EEE",
    			'E', Items.CHICKEN
    		});
		
		GameRegistry.addRecipe(new ItemStack(Items.CHICKEN, 9), new Object[] {
    			"   ",
    			" D ",
    			"   ",
    			'D', itemtwelve
    		});
		
		GameRegistry.addRecipe(new ItemStack(itemthirteen, 1), new Object[] {
    			"EEE",
    			"EEE",
    			"EEE",
    			'E', Items.COOKED_CHICKEN
    		});
		
		GameRegistry.addRecipe(new ItemStack(Items.COOKED_CHICKEN, 9), new Object[] {
    			"   ",
    			" D ",
    			"   ",
    			'D', itemthirteen
    		});
		
		GameRegistry.addRecipe(new ItemStack(itemfourteen, 1), new Object[] {
    			"EEE",
    			"EEE",
    			"EEE",
    			'E', Items.PORKCHOP
    		});
		
		GameRegistry.addRecipe(new ItemStack(Items.PORKCHOP, 9), new Object[] {
    			"   ",
    			" D ",
    			"   ",
    			'D', itemfourteen
    		});
		
		GameRegistry.addRecipe(new ItemStack(itemfifteen, 1), new Object[] {
    			"EEE",
    			"EEE",
    			"EEE",
    			'E', Items.COOKED_PORKCHOP
    		});
		
		GameRegistry.addRecipe(new ItemStack(Items.COOKED_PORKCHOP, 9), new Object[] {
    			"   ",
    			" D ",
    			"   ",
    			'D', itemfifteen
    		});
		
		GameRegistry.addRecipe(new ItemStack(itemsixteen, 1), new Object[] {
    			" F ",
    			" E ",
    			" D ",
    			'D', Items.GLASS_BOTTLE, 'E', Items.WATER_BUCKET, 'F', itemone
    		});
		
		
		
		
		GameRegistry.addSmelting(blockone, new ItemStack(itemone, 1), 0.1f);
		GameRegistry.addSmelting(blockthree, new ItemStack(blockfive, 1), 0.1f);
		GameRegistry.addSmelting(blockfour, new ItemStack(blocksix, 1), 0.1f);
		GameRegistry.addSmelting(blockseven, new ItemStack(blocknine, 1), 0.1f);
		GameRegistry.addSmelting(blockeight, new ItemStack(blockten, 1), 0.1f);
		GameRegistry.addSmelting(armorhelmettwo, new ItemStack(armorhelmetone, 1), 0.1f);
		GameRegistry.addSmelting(armorchestplatetwo, new ItemStack(armorchestplateone, 1), 0.1f);
		GameRegistry.addSmelting(armorleggingstwo, new ItemStack(armorleggingsone, 1), 0.1f);
		GameRegistry.addSmelting(armorbootstwo, new ItemStack(armorbootsone, 1), 0.1f);
	}

	public static void addBlocksAndItems() {
		
		blockone = new BlockOne("blockone");
		blocktwo = new BlockTwo("blocktwo");
		blockthree = new BlockThree("blockthree");
		blockfour = new BlockFour("blockfour");
		blockfive = new BlockFive("blockfive");
		blocksix = new BlockSix("blocksix");
		blockseven = new BlockSeven("blockseven");
		blockeight = new BlockEight("blockeight");
		blocknine = new BlockNine("blocknine");
		blockten = new BlockTen("blockten");
		blockeleven = new BlockEleven("blockeleven");
		blocktwelve = new BlockTwelve("blocktwelve");
		blockthirteen = new BlockThirteen("blockthirteen");
		blockfourteen = new BlockFourteen("blockfourteen");
		blockfifteen = new BlockFifteen("blockfifteen");
		blockpilot = new BlockPilot("blockpilot");
		genone = new WorldGen(blockone, 30, 24, 64);
		itemone = new ItemOne("itemone");
		itemtwo = new ItemTwo("itemtwo", ToolMaterial.STONE);
		itemthree = new ItemThree("itemthree", ToolMaterial.STONE);
		itemfour = new ItemFour("itemfour", 20, true);
		itemfive = new ItemFive("itemfive", ToolMaterial.STONE);
		itemsix = new ItemSix("itemsix", ToolMaterial.WOOD);
		itemseven = new ItemSeven("itemseven", ToolMaterial.IRON);
		itemeight = new ItemEight("itemeight", ToolMaterial.STONE);
		itemnine = new ItemNine("itemnine", ToolMaterial.STONE);
		itemten = new ItemTen("itemten", 5, false);
		itemeleven = new ItemEleven("itemeleven", 10, false);
		itemtwelve = new ItemTwelve("itemtwelve", 5, false);
		itemthirteen = new ItemThirteen("itemthirteen", 10, false);
		itemfourteen = new ItemFourteen("itemfourteen", 5, false);
		itemfifteen = new ItemFifteen("itemfifteen", 10, false);
		itemsixteen = new ItemSixteen("itemsixteen", 0, false);
		armorhelmetone = new ArmorItem("armorhelmetone", ARMORONE, 1, EntityEquipmentSlot.HEAD);
		armorchestplateone = new ArmorItem("armorchestplateone", ARMORONE, 2, EntityEquipmentSlot.CHEST);
		armorleggingsone = new ArmorItem("armorleggingsone", ARMORONE, 3, EntityEquipmentSlot.LEGS);
		armorbootsone = new ArmorItem("armorbootsone", ARMORONE, 4, EntityEquipmentSlot.FEET);
		armorhelmettwo = new ArmorItem("armorhelmettwo", ARMORTWO, 1, EntityEquipmentSlot.HEAD);
		armorchestplatetwo = new ArmorItem("armorchestplatetwo", ARMORTWO, 2, EntityEquipmentSlot.CHEST);
		armorleggingstwo = new ArmorItem("armorleggingstwo", ARMORTWO, 3, EntityEquipmentSlot.LEGS);
		armorbootstwo = new ArmorItem("armorbootstwo", ARMORTWO, 4, EntityEquipmentSlot.FEET);
		
	
	}

	public static void addRegisters() {

		reg(blockone);
		reg(blocktwo);
		reg(blockthree);
		reg(blockfour);
		reg(blockfive);
		reg(blocksix);
		reg(blockseven);
		reg(blockeight);
		reg(blocknine);
		reg(blockten);
		reg(blockeleven);
		reg(blocktwelve);
		reg(blockthirteen);
		reg(blockfourteen);
		reg(blockfifteen);
		reg(blockpilot);
		reg(itemone);
		reg(itemtwo);
		reg(itemthree);
		reg(itemfour);
		reg(itemfive);
		reg(itemsix);
		reg(itemseven);
		reg(itemeight);
		reg(itemnine);
		reg(itemten);
		reg(itemeleven);
		reg(itemtwelve);
		reg(itemthirteen);
		reg(itemfourteen);
		reg(itemfifteen);
		reg(itemsixteen);
		reg(armorhelmetone);
		reg(armorchestplateone);
		reg(armorleggingsone);
		reg(armorbootsone);
		reg(armorhelmettwo);
		reg(armorchestplatetwo);
		reg(armorleggingstwo);
		reg(armorbootstwo);


		
	}

	public static void reg(Block block) {
		Item item = Item.getItemFromBlock(block);
		reg(item);
	}

	public static void reg(Item item) {
			ModelResourceLocation model = new ModelResourceLocation(item.getRegistryName(), "inventory");
			ModelLoader.registerItemVariants(item, model);
			Minecraft.getMinecraft().getRenderItem().getItemModelMesher().register(item, 0, model);
	}

}