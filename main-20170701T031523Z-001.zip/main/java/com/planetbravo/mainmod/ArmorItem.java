package com.planetbravo.mainmod;

import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.item.ItemArmor;
import net.minecraft.item.ItemArmor.ArmorMaterial;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.fml.common.registry.GameRegistry;

public class ArmorItem extends ItemArmor {
	
	private ResourceLocation location;
	
    public ArmorItem(String unlocalizedName, ArmorMaterial material, int renderIndex, EntityEquipmentSlot armorType) {
		super(material, renderIndex, armorType);
		this.setUnlocalizedName(unlocalizedName);
		this.setCreativeTab(Register.mainTab);
		this.location = new ResourceLocation(Main.MODID, unlocalizedName);
		this.setRegistryName(location);
		GameRegistry.register(this);
    }
}
