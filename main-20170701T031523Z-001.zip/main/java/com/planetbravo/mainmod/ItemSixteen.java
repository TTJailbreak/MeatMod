//Start with a working food item (see tutorial above)
//Get the potion ID effects from http://minecraft-helpandinfo.weebly.com/potion-effects-ids.html
//Look for the line  effectPlayer(player, Potion.getPotionById(12), 0); and replace the 12 with
//the number from the website that you want. You can copy/paste the statement for many effects.
//Replace your ItemFood�s class code with this:
package com.planetbravo.mainmod;

import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemFood;
import net.minecraft.item.ItemStack;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.ResourceLocation;
import net.minecraft.world.World;
import net.minecraftforge.fml.common.registry.GameRegistry;

public class ItemSixteen extends ItemFood {
  
  private ResourceLocation location;
  
  public ItemSixteen(String unlocalizedName, int i, boolean b){
      super(i, 0.2f, b);
      this.setUnlocalizedName(unlocalizedName);
      this.setCreativeTab(Register.mainTab);
      this.setAlwaysEdible();
      this.location = new ResourceLocation ( Main . MODID , unlocalizedName );
      this.setRegistryName ( location );
      GameRegistry . register ( this );

  }
  
  @Override
  protected void onFoodEaten(ItemStack stack, World world, EntityPlayer player) {
      super.onFoodEaten(stack, world, player);
      
      effectPlayer(player , Potion.getPotionById(2) , 1 );
      effectPlayer(player , Potion.getPotionById(5) , 3 );
      
  }
  
  private void effectPlayer ( EntityLivingBase player , Potion potion , int amplifier ) {
      if ( player . getActivePotionEffect ( potion ) == null ||
      player.getActivePotionEffect ( potion ). getDuration () <= 1)
      player.addPotionEffect ( new PotionEffect ( potion , 159 , amplifier , true , true ));
  }
  
}
