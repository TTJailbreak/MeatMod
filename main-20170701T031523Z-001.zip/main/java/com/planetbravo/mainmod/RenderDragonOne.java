//Copy this code in a class called RenderDogOne
package com.planetbravo.mainmod;

import org.lwjgl.opengl.GL11;

import net.minecraft.client.Minecraft;
import net.minecraft.client.model.ModelWolf;
import net.minecraft.client.renderer.entity.RenderDragon;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.client.renderer.entity.RenderWolf;
import net.minecraft.client.renderer.entity.RenderZombie;
import net.minecraft.entity.boss.EntityDragon;
import net.minecraft.entity.monster.EntityZombie;
import net.minecraft.entity.passive.EntityWolf;
import net.minecraft.util.ResourceLocation;

public class RenderDragonOne extends RenderDragon {

	private static final ResourceLocation textureLocation = new ResourceLocation(
			Main.MODID + ":" + "textures/entities/dragonone.png");
	
	public RenderDragonOne(RenderManager manager) {
		super(manager);
	}



	@Override
	protected ResourceLocation getEntityTexture(EntityDragon par1Entity) {
		return textureLocation;
	}

}