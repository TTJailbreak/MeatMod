package com.planetbravo.mainmod;

import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.item.*;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.fml.common.registry.GameRegistry;

//Change ItemSword to ItemPickaxe, ItemSpade, ItemAxe, ItemHoe
public class ItemFive extends ItemSpade {
	
	private ResourceLocation location;

	public ItemFive(String unlocalizedName, ToolMaterial material) {
		super(material);
		this.setUnlocalizedName(unlocalizedName);
		this.setCreativeTab(Register.mainTab);
		this.location = new ResourceLocation(Main.MODID, unlocalizedName);
		this.setRegistryName(location);
		GameRegistry.register(this);
	}

}